import java.io.*;

class Main {
  public static void main(String[] args) /*throws IOException*/ {
    FileReader fin = null;

    try{
      fin = new FileReader("/etc/passwd");
      int c;
      while((c = fin.read()) != -1){
      System.out.print((char)c);
      }
      fin.close();
    }
    catch(FileNotFoundException e){
      System.out.println("파일 없음");
    }
    catch(IOException e) {
      System.out.println("파일 입축력 오류");
    }
    
  }
}