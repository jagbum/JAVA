import java.util.Scanner;

public class YearSchedule{
  public MonthSchedule[] mSchedules = new MonthSchedule[12];
  public int[] nDays = {31, 28,31,30,31,30,31,31,30,31,30,31};
  private int year;
  public YearSchedule(int year){
    this.year = year;
  }
  public void run(){
    Scanner scanner = new Scanner(System.in);
    System.out.println(year+"년도 스케줄 관리");
    while(true) {
      System.out.println("달을 선택하세요, 종료 0");
      
      int month;
      try{ 
        month = scanner.nextInt();
      } catch(Exception e){
        System.out.println("다시 입력하세요!");
        scanner.nextLine(); // 버퍼삭제
        continue;
      }

      if(month ==0) break;
      if(month>12 || month<1) continue;

      if(mSchedules[month-1] == null)
        mSchedules[month-1] = new MonthSchedule(nDays[month-1]);
      
      mSchedules[month-1].run(month);
    }
  }  
}