class Day{
  private String work;
  public void setWork(String work) { this.work = work;} // setter
  public String get() {return work;} //getter
  public void show(){
    if(work == null) System.out.println("없습니다.");
    else System.out.println(work +"입니다.");
  }

  public Day(String work) {
    //this.work = work;
    setWork(work);
  }
}