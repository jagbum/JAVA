import java.util.Scanner;

public class MonthSchedule{
  private int nDays;
  private Day[] days;

  public MonthSchedule(int nDays) {
    this.nDays = nDays;
    days = new Day[nDays];
  }

  public int getIntNum(){
    Scanner scanner = new Scanner(System.in);
    int num;
    while(true)
    {
      try{
        num = scanner.nextInt();
      } 
      catch(Exception e) {
        System.out.println("정수값을 다시 입력하세요!");
        scanner.nextLine(); // 버퍼삭제
        continue;
      }
      break;
    }
    return num;
  }

  public void run(int month) {
    System.out.println(month +"월달 스케쥴 관리 프로그램");
    //Scanner scanner = new Scanner(System.in);

    while(true) {
      System.out.print("할일(입력:1, 보기:2, 끝내기:3) ?");
      //int menu = scanner.nextInt();
      int menu = getIntNum();

      switch(menu){
        case 1:
          input();
          break;
        case 2:
          view();
          break;
        case 3:
          //System.out.println("종료합니다.");
          return;
        default:
          System.out.println("잘못 입력했습니다.");  
      }
    }
  }

  public void input() {
    System.out.print("날짜(~" +nDays+")?");
    Scanner scanner = new Scanner(System.in);
    //int day = scanner.nextInt();
    int day = getIntNum();
    System.out.print("할일(빈칸없이입력)?");
    String work = scanner.next();

    if(day>=1 && day <=nDays) {
      //days[day-1] = new Day();
      //days[day-1].setWork(work);
      days[day-1] = new Day(work);
    }else{
      System.out.print("날짜를 잘못입력하셨습니다");
    }
  }

  public void view() {
    System.out.print("날짜(~" +nDays+")?");
    Scanner scanner = new Scanner(System.in);
    //int day = scanner.nextInt();
    int day = getIntNum();
    if(days[day-1] != null && day>=1 && day <=nDays) {
      System.out.print((day)+"일의 할 일은");
      days[day-1].show();
    } else{
      System.out.print("날짜를 잘못입력하셨습니다");
    }
  }
}