import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    YearSchedule y2021 = new YearSchedule(2021);
    y2021.run();
    
    //MonthSchedule april = new MonthSchedule(30);
    //april.run();
  /*  MonthSchedule[] mSchedules = new MonthSchedule[12];
    int[] nDays = {31, 28,31,30,31,30,31,31,30,31,30,31};

    while(true) {
      System.out.println("달을 선택하세요, 종료 0");
      Scanner scanner = new Scanner(System.in);
      int month;
      try{ 
        month = scanner.nextInt();
      } catch(Exception e){
        System.out.println("다시 입력하세요!");
        scanner.nextLine(); // 버퍼삭제
        continue;
      }

      if(month ==0) break;
      if(month>12 || month<1) continue;

      if(mSchedules[month-1] == null)
        mSchedules[month-1] = new MonthSchedule(nDays[month-1]);
      
      mSchedules[month-1].run(month);
    }*/
  }
}