import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Main extends JFrame{

  public Main() {
    setTitle("12-1"); //= super("")
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setContentPane(new MyPanel());
    setSize(300,300);
    setVisible(true);
    
  }

  class MyPanel extends JPanel  implements Runnable{
    private int x,y;

    public MyPanel() {
      x =100;
      y =100;

      this.addMouseListener(new MouseAdapter(){
        private Thread th = null;
        
        public void mousePressed(MouseEvent e){
          if(th == null){
            th = new Thread(MyPanel.this);
            th.start();
          }
        }
      });
    }

    public void paintComponent(Graphics g){
      super.paintComponent(g);
      g.setColor(Color.MAGENTA);
      g.drawOval(x,y,50,50);
    }

    public void run() /*throws InterruptedException*/ {
      while(true){
        try{
          Thread.sleep(400);
        } catch(InterruptedException e){
          return;
          //e.printStackTrace();
        }

        x = (int) (Math.random() *this.getWidth());
        y = (int) (Math.random() *this.getHeight());

        repaint();

      }
    }
  }

  public static void main(String[] args) {
   new Main();
  }
}