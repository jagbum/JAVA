import java.util.Scanner;

class Main {
  
  public static void main(String[] args) {
  
    int i, j;
    i = 200;
    j= 100;

    System.out.print("Hello world!\n"); //  \n 줄바꿈
    System.out.println("영남대학교");   // ln 줄바꿈
    System.out.println("컴퓨터공학과");  
    System.out.println(i);
    System.out.println(j);
  
  
    // 사용자 입력받기 l
    Scanner scanner = new Scanner(System.in);

    System.out.println("나이 입력");
    int age = scanner.nextInt();
    System.out.println("당신의 나이는"+ age +"입니다.");
    System.out.println("이름 입력");
    String name = scanner.next();
    /*sysout*/System.out.println("이름은" + name +"입니다."); //scanner버퍼 공백기준
    

    //조건문
    if( age > 19 )
      System.out.println("성인입니다.");
    else
      System.out.println("미성년자입니다.");

    switch( age / 10 ){
      case 1:
        System.out.println("10대입니다.");
        break;
      case 2:
        System.out.println("20대입니다.");
        break;
      case 3:
        System.out.println("30대입니다.");    
        break;
      case 4:
        System.out.println("40대입니다.");
        break;
      case 0:
        System.out.println("아동입니다.");
        break;
      default:
        System.out.println("ㅇㅇㅇ");
        break;

    }
  }
}