public class StringStack implements Stack{
  private String[] element;
  private int tos; //top of stack

  public StringStack(int capacity){
    element = new String[capacity];
    tos =0;
  }

  @Override
  public int length() {
    return tos;
  }

  @Override
  public int capacity(){
    return element.length;
  }

  @Override
  public boolean push(String src) {
    
    if(tos == capacity())  return false;
    else{
      element[tos++] = src;
      /*element[tos] = src;
      tos++;*/
      return true;
    }
  }

  @Override
  public String pop(){
    if(tos == 0) return null;//stack empty
    else
      return element[--tos];
  }

}