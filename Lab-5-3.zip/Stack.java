interface Stack {
  int length();
  int capacity();
  String pop();
  boolean push(String vail);
}