import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.print("총 스택 크기>>");
    int n = scanner.nextInt();

    StringStack ss = new StringStack(n);

    while(true) {
      System.out.print("문자열 입력>>");
      String str = scanner.next();
      if(str.equals("그만")) {
        break;
      }

      if( !ss.push(str) ) System.out.println("Stack Full!!");
      
    }

    System.out.println("스택에 저장된 문자열 팝:");
    
    int len = ss.length();
    for(int i = 0; i< len ;i++){ //ss.length시에 수가 줄어서 잘못됨
      System.out.print(ss.pop()+" ");
    }
    System.out.println();
  }
}