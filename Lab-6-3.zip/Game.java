public class Game{
  private Player[] players= new Player[2];

  public Game() {
    players[0] = new Player("철수");
    players[1] = new Computer("컴퓨터"); //업캐스팅
  }

  public Game(Player player1, Player player2) {
    players[0] = player1;
    players[1] = player2;
  }

  public void run() {
    int player1, player2;
    while (true) {
      player1 = players[0].turn();
      //if(player1 == 4) break;
      player2 = players[1].turn();

      if(player1 == 4|| player2 == 4) break;
      int diff = player1 - player2;

      System.out.println(players[0].getName()+":"+players[0].getString()+","+players[1].getName()+":"+players[1].getString());

      switch(diff) {
        case 0:
        System.out.println("비겼음");
        case -1:
        case 2:
          System.out.println(players[1].getName() +"가 이겼음");
          break;
        case 1:
        case -2:
          System.out.println(players[0].getName() +"가 이겼음");
          break;
      }
    }
  }

}