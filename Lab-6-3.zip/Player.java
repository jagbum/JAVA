import java.util.Scanner;

public class Player {
  private String name;
  private String s[] = {"가위","바위","보"};
  protected int select;

  public Player(String name){
    this.name = name;
  }

  public String getName() {return name;}
  public  String  getString() {return s[select-1];}

  public int turn() {
    Scanner scanner = new Scanner(System.in);
    while(true) {
      System.out.print("가위(1), 바위(2), 보(3), 종료(4) >>");
      try {
        select = scanner.nextInt();
      }
      catch(Exception e){
        continue;
      }
      if(select <1 || select >4) continue;

      return select;
    }
  }


}