
class Main {
  public static void main(String[] args) {
    System.out.println("가위바위보");
    //Game game = new Game();
    //game.run();
    //Player player1 = new Computer("컴퓨터1");
    //Computer player2 = new Computer("컴퓨터2");

    Player player1 = new Player("컴퓨터1");
    Player player2 = new Player("컴퓨터2");

    Game game = new Game(player1,player2);
    game.run();


  }
}