class Main {
  public static void main(String[] args) {
   PhoneExplorer phoneExplorer = new PhoneExplorer("phone.txt");
   phoneExplorer.run();
  }
}