import java.util.*;
import java.io.*;

public class PhoneExplorer {
  private String dataFilename;
  private HashMap<String, String> PhoneBook = new HashMap<>();

  public PhoneExplorer(String dataFilename) {
    this.dataFilename = dataFilename;
  }

  private void readPhoneFile() {
    try{
      Scanner scanner = new Scanner(new FileReader(dataFilename));
    
      while(scanner.hasNext()) {
        String name = scanner.next();
        String phone = scanner.next();
        PhoneBook.put(name,phone);
      }
      scanner.close();
    } catch(IOException e) {
      System.out.println(dataFilename+"읽기 오류");
      e.printStackTrace();
    }
      System.out.println("총 "+ PhoneBook.size()+ "개의 전화번호를 읽었습니다.");

  }
  
    private void processQuery() {
      Scanner scanner = new Scanner(System.in);
      while(true){
        System.out.print("이름>>");
        String name = scanner.next();
        if(name.equals("그만")) break;

        String tel = PhoneBook.get(name);
        if(tel == null){
          System.out.println(name+"는 없는 사랍입니다.");
        } else{
          System.out.println(tel);
        }
      }
      scanner.close();
    }
  
    public void run(){
      readPhoneFile();
      processQuery();
    }

}