import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.text.BadLocationException;

class Main extends JFrame{
  private JTextArea ta = new JTextArea(5,10);
  private JSlider slider = new JSlider(0,100,0);

  public Main(){
    setTitle("11-3");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container c = getContentPane();

    c.setLayout(new BorderLayout());
    c.add(new JScrollPane(ta),BorderLayout.CENTER);
    c.add(slider,BorderLayout.SOUTH);
    
    slider.setMajorTickSpacing(20);
    slider.setMajorTickSpacing(5);
    slider.setPaintLabels(true);
    slider.setPaintTicks(true);

    slider.addChangeListener(new ChangeListener(){
      @Override
      public void stateChanged(ChangeEvent e) {
        JSlider s = (JSlider) e.getSource();
        if(ta.getText().length() <= s.getValue())
          s.setValue(ta.getText().length());              
        else {
          try{
            ta.setText(ta.getText(0, e){
        JTextArea t = (JTextArea) e.getSource();
        if(t.getText().length() <= 100)
          slider.setValue(ta.getText().length());
        else{
            t.setText(ta.getText().substring(0,100));
        }
      }
    });

    setSize(300, 300);
    setVisible(true);
  }



  public static void main(String[] args) {
    new Main();
  }
}
