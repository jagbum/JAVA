public class Won2Dollar extends Converter {

  public Won2Dollar(double ratio) {
    this.ratio = ratio;
  }
  
  //Java Annotation
  
  @Override 
  protected String srcString() {
    return "원";
  }

  protected String destString() {
    return "달러";
  }

  protected double convert(double src) {
    return src/ratio;
  }

  @Override
  public void test(int x) {
    System.out.println("테스트")
  }

}