class Main {
  public static void main(String[] args) {
    LocationManager lm = new LocationManager();
    lm.run();
  }
}