public class Location{
  private String city;
  private double longitude; // 경도
  private double latitude; // 위도

  public Location(String city, double longitude, double latitude){
    this.city = city;
    this.longitude = longitude;
    this.latitude = latitude;
  }

  @Override
  public String toString(){
    return city+"\t"+longitude+"\t"+latitude;
  }

  
}
