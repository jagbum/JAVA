import java.util.*;

public class LocationManager{
  private Scanner scanner = new Scanner(System.in);
  private HashMap<String, Location> dept = new HashMap<String, Location>();

  private void read(){
    System.out.println("도시, 경도, 위도를 입력하세요");
    for(int i = 0; i<4; i++) {
      System.out.print(">>");
      String inputText =  scanner.nextLine();

      StringTokenizer st = new StringTokenizer(inputText,",");
      String city = st.nextToken().trim();
      double longitude = Double.parseDouble(st.nextToken().trim());
      double latitude = Double.parseDouble(st.nextToken().trim());

      Location loc = new Location(city, longitude, latitude);

      dept.put(city, loc);
    }
  }

  private void printAll(){
    // HashMap 키값 모두 가져오기
    Set<String> keys = dept.keySet();
    Iterator<String> it = keys.iterator();

    System.out.println("----------------------------");
    while(it.hasNext()){
      String city = it.next();
      Location loc = dept.get(city);
      System.out.println(loc);
    }
    System.out.println("----------------------------");
  }

  private void processQuery() {
    while(true) {
      System.out.println("도시 이름>>");
      String city = scanner.nextLine();
      
      if(city.equals("그만")) break;

      Location loc = dept.get(city);

      if(loc == null) {
        System.out.println(city+"는 없습니다.");
      }
      else {
        System.out.println(loc);
      }
    }
  }

  public void run(){
    read();
    printAll();
    processQuery();
  }


}