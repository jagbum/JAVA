package base;

public class Shape {
  public void draw() {System.out.println("Shape");}
}