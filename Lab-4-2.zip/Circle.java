public class Circle {
  private double x,y;
  private inr radius;
  public Circle(doublex, double y, int radius) {
    this.x = x;
    this.y = y;;
    this.radius =radius;
  }

  public void show() {
    System.out.println("("+x+","+y+")"+ radius);
  }
  
}