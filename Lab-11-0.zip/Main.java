import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;

class Main extends JFrame{
private JSlider[] sl = new JSlider[3];
private JLabel colorLabel;

public Main(){
  setTitle("Slider Ex");
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  Container c = getContentPane();
  c.setLayout(new FlowLayout());

  colorLabel = new JLabel("SLIDER EXAMPLE");
  colorLabel.setOpaque(true);
  colorLabel.setBackground(new Color(128,128,128));
  //c.add(colorLabel);

  for(int i=0; i<sl.length; i++){
    sl[i] = new JSlider(JSlider.HORIZONTAL, 0, 255, 128);
    sl[i].addChangeListener(new ChangeListener(){
      @Override
      public void stateChanged(ChangeEvent e){
        int r = sl[0].getValue();
        int g = sl[1].getValue();
        int b = sl[2].getValue();

        colorLabel.setBackground(new Color(r,g,b));
      }
    });
    c.add(sl[i]);
  }

  c.add(colorLabel);
  setSize(300,250);
  setVisible(true);
}

  public static void main(String[] args) {
    new Main();
  }
}