import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Main extends JFrame {
  
  public Main() {
    setTitle("10-3"); // super("10-3")

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container c = getContentPane();
    c.setLayout(null);

    JLabel label = new JLabel("C");
    c.add(label);

    label.setSize(20,20);
    label.setLocation(100, 100);


    label.addMouseListener(new MouseAdapter (){
      public void mousePressed(MouseEvent e){
        JLabel la  = (JLabel)e.getSource();
        Container c = label.getParent();

        int xBound = c.getWidth() - la.getWidth();
        int yBound = c.getHeight() - la.getHeight();

        int x = (int)(Math.random()*xBound);
        int y = (int)(Math.random()*yBound);

        la.setLocation(x, y);

      }
    });

    setSize(300,300);
    setVisible(true);
  }
 
 
 
 
  public static void main(String[] args) {
    new Main();
  }
}