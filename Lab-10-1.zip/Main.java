import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class Main extends JFrame {

  public Main() {
    setDefaultCloseOperation(EXIT_ON_CLOSE);

    Container c = getContentPane();
    c.setLayout(new FlowLayout());

    JLabel label = new JLabel("Love Java");
    label.setFont(new Font("Arial",Font.PLAIN, 10));
    c.add(label);

    label.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_LEFT){
          JLabel la = (JLabel) e.getSource();
          String text =  la.getText();
          String firstchar = text.substring(0,1);
          String remainString = text.substring(1);
          la.setText(remainString + firstchar);
        }
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT){
          JLabel la = (JLabel) e.getSource();
          String text =  la.getText();
          String lastchar = text.substring(text.length()-1);
          String remainString = text.substring(0,text.length()-1);
          la.setText(lastchar + remainString);
        }
        else if(e.getKeyChar() == '+'){
          JLabel la = (JLabel) e.getSource();
          Font f = la.getFont();
          int size = f.getSize();
          la.setFont(new Font("Arial",Font.PLAIN, size + 5));
        }
        else if(e.getKeyChar() == '-'){
          JLabel la = (JLabel) e.getSource();
          Font f = la.getFont();
          int size = f.getSize();
          if(size - 5 > 4)  
            label.setFont(new Font("Arial",Font.PLAIN, size - 5));
        }
      }
    });

    label.addMouseWheelListener(new MouseAdapter() {
      @Override
      public void mouseWheelMoved(MouseWheelEvent e){
        int n = e.getWheelRotation();
        if(n > 0) {
          JLabel la = (JLabel) e.getSource();
          Font f = la.getFont();
          int size = f.getSize();
          if(size - 5 > 4)
            label.setFont(new Font("Arial",Font.PLAIN, size - 5));
        }
        else {
          JLabel la = (JLabel) e.getSource();
          Font f = la.getFont();
          int size = f.getSize();
          la.setFont(new Font("Arial",Font.PLAIN, size + 5));
        }
      }
    });

    setSize(250,250);
    setVisible(true);

    label.setFocusable(true);
    label.requestFocus();
  }

  public static void main(String[] args) {
    new Main();
  }
}