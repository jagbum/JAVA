
public class Grade {
  private int math;
  private int scie;
  private int eng;
  
  public Grade(int math, int sci, int eng) {
    this.math = math;
    /*this*/scie = sci;
    this.eng = eng;
  } 

  public int average() {
    return (math+ scie + eng)/3;
  }
}