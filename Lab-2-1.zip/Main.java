import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    System.out.println("정수값 3개를 입력하세요:");

    Scanner scanner = new Scanner(System.in);

    int a,b,c;
    
    a = scanner.nextInt();
    b = scanner.nextInt();
    c = scanner.nextInt();
  
    int med;
    if ( (a >= b && a <= c) || (a >= c && a <= b) ) 
      med = a;
    else if ( (b >= a && b <= c) || (b >= c && b <= a) )
      med = b;
    else
      med = c;

      System.out.println("중간 값은" + med);

      scanner.close(); 
  }
}