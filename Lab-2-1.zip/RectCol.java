import java.util.Scanner;

public class RectCol {

  public static void main(String[] args) {
    Scanner scanner  = new Scanner(System.in);

    System.out.println("점(x,y) 좌표 입력");

    int x,y;
    x = scanner.nextInt();
    y = scanner.nextInt();

    if( x >= 100 && x <= 200 && y>= 100 && y <= 200 )
      System.out.println("("+x+","+y+") 는 사각형 안에 있습니다");
    else
      System.out.println("("+x+","+y+") 는 사각형 안에 없습니다");
  
  }
}