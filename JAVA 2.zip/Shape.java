abstract class Shape { //추상클래스 Shape 선언
  public abstract void draw(); //추상메소드 draw()선언
} // 추상클래스 Shape 끝