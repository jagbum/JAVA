class Main { // Main 클래스 선언
  public static void main(String[] args) { //main() 메소드 선언
    Beauty beauty  = new Beauty(); // Beauty 객체 beauty 생성
    beauty.run(); // Beauty 클래스의 run 매소드 호출
  } // main() 메소드 끝
} // Main클래스 끝