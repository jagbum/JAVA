class Rect extends Shape { // Shape을 상속받은 Rect 클래스 선언
  public void draw(){ // draw()추상 메소드 구현
    System.out.println("Rect"); // Rect 출력
  } // draw()메소드 끝
} // Rect 클래스 끝