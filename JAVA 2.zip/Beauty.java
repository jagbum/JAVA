import java.util.*; // java.util 패키지의 모든 클래스 경로명 알림

public class Beauty { // Beauty 클래스 선언
  private Scanner scanner = new Scanner(System.in); // private 멤버 Scanner객체 생성
  private Vector<Shape> v = new Vector<Shape>(); // private 멤버 Shape 객체를 다루는 벡터 v 생성
  
  private void insert() { //private 멤버 insert() 메소드 선언
    System.out.print("Line(1), Rect(2), Circle(3)>>"); // Line(1), Rect(2), Circle(3)>> 출력
    int shapenum = scanner.nextInt(); // shapenum 정수 읽기
    if(shapenum == 1) v.add(new Line()); // shapenum이 1일때 Line() 객체 삽입 
    else if(shapenum == 2) v.add(new Rect()); // shapenum이 2일때 Rect() 객체 삽입 
    else if(shapenum == 3) v.add(new Circle()); // shapenum이 3일때 Circle() 객체 삽입 
  } // insert() 메소드 끝

  private void delete(){ // private멤버 delete() 메소드 선언
    System.out.print("삭제할 도형의 위치>>"); // 삭제할 도형의 위치>> 출력
    int deletenum = scanner.nextInt(); // deletenum 정수 읽기
    if(0 < deletenum && deletenum <= v.size()) // deletenum이 0보다 크고 벡터 v의 사이즈 이하일 경우
       v.remove(deletenum-1); // 인덱스 deletenum-1의 위치의 객체 삭제
    else System.out.println("삭제할 수 없습니다."); // deletenumdl 0보다 크고 벡터 v의 사이즈 이하가 아닐 경우 삭제할 수 없습니다. 출력
  } // delete() 메소드 끝

  private void see() { // private멤버 see() 메소드 선언
    for(int i =0; i < v.size(); i++) { // i가 0부터 v의 사이즈보다 1작은 수가 될 때까지 1씩 더하며 반복 실핼
      Shape s = v.get(i); // 벡터 i 번째 Shape 객체 얻어내기 
      s.draw(); // 각 Shape 객체에 맞는 draw() 메소드 실행
    } // for문 끝
  } // see() 메소드 끝 

  public void run(){ // public멤버 run() 메소드 선언
    System.out.println("그래픽 에디터 beauty을 실행합니다."); // 그래픽 에디터 beauty을 실행합니다. 출력
    while(true){ // while(true)를 사용하여 무한루프 시작
      System.out.print("삽입(1), 삭제(2), 모두 보기(3), 종료(4)>>"); // 삽입(1), 삭제(2), 모두 보기(3), 종료(4)>> 출력
      int choice = scanner.nextInt(); // choice 정수 읽기
      if (choice == 1) insert(); // choice가 1일 경우 insert() 메소드 실행
      else if (choice == 2) delete(); // choice가 2일 경우 delete() 메소드 실행
      else if (choice == 3) see(); // choice가 3일 경우 see() 메소드 실행
      else if (choice == 4) { // choice가 4일 경우
        System.out.println("beauty을 종료합니다"); // beauty을 종료합니다 실행 
        break; // while 문을 벗어남
      } //  choice가 4인 경우 끝
    } // while문 끝 
  } // run() 메소드 끝 

} // Beauty 클래스 끝  