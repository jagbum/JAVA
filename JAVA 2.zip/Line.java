class Line extends Shape { // Shape을 상속받은 Line 클래스선언
  public void draw(){ // draw()추상 메소드 구현
    System.out.println("Line"); // Line 출력
  } //draw()메소드 끝
} // Line 클래스 끝