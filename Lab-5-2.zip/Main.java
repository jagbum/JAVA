import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    Km2Mile toMile = new Km2Mile(1.6);
    toMile.run();

    //scanner.nextLine();
  
    Mile2Km toKm = new Mile2Km(0.621);
    toKm.run();
  }
}