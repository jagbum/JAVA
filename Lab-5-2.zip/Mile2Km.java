public class Mile2Km extends Converter{
  public Mile2Km(double ratio) {
    this.ratio = ratio;
  }

  @Override
  protected String srcString(){
    return "Mile";
  }

  @Override
  protected String destString(){
    return "Km";
  }

  @Override
  protected double convert(double src) {
    return src/ratio;
  }


}