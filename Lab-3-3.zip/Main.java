import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    
  /*for(int i = 0; i < args.length; i++) {
      System.out.print(args[i]);
    }

    for(String arg : args) {
      System.out.print(arg);
    }*/
    
    int sum = 0;
    for(String arg: args) {
      // String --> int
      try {
        int n = Integer.parseInt( arg );
        sum += n;
      }
      catch(NumberFormatException e){
        System.out.println(arg + "정수 아님");
      }
    }

    System.out.println(sum);
  }
}