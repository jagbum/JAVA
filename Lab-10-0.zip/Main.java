import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Main extends JFrame{

  private JLabel la = new JLabel("hello");
  public Main(){
    setTitle("Mouse Example");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container c = getContentPane();

    c.addMouseListener(new MyListener() );
    c.addMouseMotionListener(new MyListener() );
    c.addKeyListener(new KeyAdapter(){
      public void keyPressed(KeyEvent e){
        int keyCode = e.getKeyCode();

        switch(keyCode){
          case KeyEvent.VK_UP:
            la.setLocation(la.getX(), la.getY()-10);
            break;
          case KeyEvent.VK_DOWN:
            la.setLocation(la.getX(), la.getY()+10);
            break;
          case KeyEvent.VK_LEFT:
            la.setLocation(la.getX()-10, la.getY());
            break;
          case KeyEvent.VK_RIGHT:
            la.setLocation(la.getX()+10, la.getY());
            break;
        }
      }
    });
   
   
    c.setLayout(null);
    la.setSize(50,20);
    la.setLocation(30,30);

    c.add(la);

    setSize(250,250);
    setVisible(true);
    c.setFocusable(true);
    c.requestFocus();
  }

  private class MyListener extends MouseAdapter{
    @Override
    public void mousePressed(MouseEvent e){
      int x = e.getX();
      int y = e.getY();

      la.setLocation(x,y);
    }

    @Override
    public void mouseDragged(MouseEvent e){
       int x = e.getX();
      int y = e.getY();

      la.setLocation(x,y);
    }

    @Override
    public void mouseClicked(MouseEvent e){
      if(e.getClickCount() ==2) {
        int r = (int)(Math.random() *256);
        int g = (int)(Math.random() *256);
        int b = (int)(Math.random() *256); 

        Component c = (Component)e.getSource();
        c.setBackground(new Color(r,g,b));
      }
    }
  }

  public static void main(String[] args) {
    new Main();
  }
}