import java.util.Scanner;

class Main {
  public static void main(String[] args) {
   System.out.print("정수를 입력하시오>>");

   Scanner scanner = new Scanner(System.in);

   int n = scanner.nextInt();
   
   for(int i = n; i > 0 ; i--){
     for(int j = 0; j < i ; j++){
       System.out.print("*");

     }
    System.out.println("");
   }

   scanner.close(); 
  }
}