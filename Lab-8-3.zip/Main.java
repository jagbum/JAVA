class Main {
  public static void main(String[] args) {
    WordSearch wordsearch = new WordSearch();
    wordsearch.run();



  }
}