import java.util.*;
import java.io.*;

public class WordSearch{

  private File targetFile = null;
  
  private Vector<String> lineVector = new Vector<String>();

  private void readFile(String fileName){
    targetFile = new File(fileName);
    try{
      Scanner fScanner = new Scanner(new FileReader(targetFile));
      while(fScanner.hasNext()){
        String line = fScanner.nextLine();
        lineVector.add(line);
      }
      fScanner.close();
    }catch(IOException e) {
      System.out.println(fileName+ "읽기 오류");
    } 
  }

  private Vector<Integer> searchWord(String word) {
    Vector<Integer> noVector = new Vector<>();
    for(int i = 0;  i<lineVector.size();i++) {
      String line = lineVector.get(i);
      if(line.indexOf(word) != -1){
        noVector.add(i);
      }
    }  
    return noVector;  
  }

  private void printLines(Vector<Integer> noVector) {
    for(int  i=0; i <noVector.size() ; i++){
      int lineno = noVector.get(i);
      String line = lineVector.get(lineno);
      System.out.println((lineno+1) + ":"+line);
    }
  }

  public void run(){
    System.out.print("파일: ");
    Scanner scanner = new Scanner(System.in);
    String filename = scanner.nextLine();
    readFile(filename);
    while(true){
      System.out.print("검색할 단어>>");
      String word = scanner.nextLine();
      if(word.equals("그만")) break;
      Vector<Integer> noVector =  searchWord(word);
      printLines(noVector);
    }
    scanner.close();
  }



}