import java.io.*;
import java.util.*;

class Main {
  public static void main(String[] args) {
    String filename;
    
    if(args.length > 0){
      filename = args[0];
    } else {
     filename = "/etc/passwd" ;
    }
    System.out.println(filename+"파일을 읽어 출력합니다");
    
    try{      
      Scanner fscanner = new Scanner(new FileReader("/etc/passwd"));
      int lineNumber = 1;
      while(fscanner.hasNext()) {
        String line = fscanner.nextLine();
        System.out.printf("%4d: ", lineNumber++);
        System.out.println(line);
        //lineNumber++;
      }
    } catch(IOException e) {
      System.out.println("입출력 오류");
    }
  }
}